# Biodigester temperature control

Automatic temperature regulation for the biodigester, with a monitoring app and
a simulated digester to test against. Everything talks over MQTT, so the
simulator can later be swapped for the real sensor and heater without touching
the controller or the app.

New to the code? Start with [BEGINNER_GUIDE.md](BEGINNER_GUIDE.md) for a reading
order, a map of the programs and a small heating example that needs no broker.

## Set up (once)

```
brew install mosquitto
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Run

Start the broker, then open three more terminals in this folder.

```
brew services start mosquitto     # the broker, in the background
python3 simulator.py              # terminal 1: the pretend digester
python3 controller.py             # terminal 2: the controller
python3 dashboard.py              # terminal 3: the browser monitoring app
python3 publisher.py              # optional terminal 4: demo pressure and pH
```

Activate `.venv` in each terminal first (`source .venv/bin/activate`). Open
http://localhost:8050 in your browser. The Live tab shows sensor readings,
history, controller status, the confirmed active range and alarms. The Report
tab compares selected sensors over a chosen time range.

The order does not matter. Each program keeps trying until the broker answers.
To stop the broker later: `brew services stop mosquitto`.

The browser app integrates the dashboard from `OneDrive_2026-10-07.zip` with
the existing independent temperature controller. All components now share
`BROKER_HOST`, `BROKER_PORT` and the `biodigester/...` topics in `config.py`.
The archive's public broker and separate random temperature publisher are
replaced by the project's local broker and heater-responsive simulator.
`publisher.py` supplies only illustrative pressure and pH readings; neither
sensor has automatic control or a validated operating target configured.

Live readings are logged to `data/readings.csv`, relative to this project even
when launched from another folder. Retained sensor readings are labelled as
saved and are not logged again. Silent sensors are labelled stale after
`STALE_AFTER_S`. A saved controller status cannot enable range controls until
a live update arrives. Range requests use the existing validation rules; the
controller reply and active range confirm whether a request was accepted.

The original archive CSV is preserved separately in `samples/readings.csv`;
it is simulated reference data and is not loaded into the live log. Archive
documentation was used as reference, not as instructions to execute.

The desktop monitor remains available with `python3 app.py`. Both monitors
can run together; closing either monitor leaves the controller running.
Run one dashboard process only: its MQTT connection and CSV lock are in memory.
The browser server defaults to this computer only (`127.0.0.1:8050`).

**What you should see.** The digester starts at 34 °C, below the range, so the
controller heats it. Above 37 °C the heater switches off and the temperature
drifts below 35 °C, where heating starts again. One full cycle takes about a
minute and a half, because the simulator runs 60 times faster than real life.

## Demo sequence for the video

Each step shows one thing the system does. Timings assume the default settings.

| Step | Do this | What happens |
|---|---|---|
| 1 | Let it run for one cycle | Temperature rises and falls inside the green band |
| 2 | Press **Silence sensor** | After about 10 s: sensor fault, heater off, reading labelled stale |
| 3 | Press **Clear fault** | Readings return and regulation resumes |
| 4 | Press **Break heater** while it is heating | After about 5 s: "The heater is not doing what it was told." |
| 5 | Press **Clear fault** | The alarm clears |
| 6 | Enter 40 and 38, press **Save range** | The range is refused with an explanation |
| 7 | Press Ctrl+C in the controller terminal | App shows "Controller offline"; the heater is off |
| 8 | Close the app while the controller runs | Regulation carries on without it |

For step 7, closing the terminal window instead of pressing Ctrl+C shows the
harder case: the controller dies without warning, the broker announces it
offline, and the heater switches itself off after 10 s of silence.

## Tests

```
python3 -m pytest -v test_control_logic.py    # control rules and fault recovery, no broker needed
python3 -m pytest -v test_end_to_end.py       # 7 tests, about a minute, needs the broker
python3 -m pytest -v test_monitoring.py       # dashboard integration, no broker needed
python3 mutation_check.py                     # optional: checks the tests themselves
```

- `test_control_logic.py` tests the rules: boundaries, bad readings, timers,
  alarms, one metamorphic test, and closed-loop runs against the simulated tank.
- `test_end_to_end.py` starts its own simulator and controller and injects each
  fault over MQTT. Stop your own simulator and controller first. It also resets
  the saved range on the broker.
- `mutation_check.py` makes 19 deliberate mistakes in the logic, one at a time,
  and reports whether the tests caught each one.

## Experiment

```
python3 experiment.py
```

Runs two simulated days per strategy in about a second, prints a comparison
table and saves `experiment_results.png`. It uses the same `Regulator` as the
live controller and the same `DigesterModel` as the simulator.

To watch the baseline strategy live instead: `python3 controller.py --strategy simple`.

## Files

| File | What it is |
|---|---|
| `config.py` | Every setting. No logic. |
| `control_logic.py` | The regulation rules. Plain Python, no MQTT. |
| `controller.py` | Runs the rules over MQTT. No window. |
| `simulator.py` | Pretend sensor and heater on MQTT, with fault injection. |
| `digester_model.py` | The physics behind the simulator. |
| `dashboard.py` | Browser monitoring app: live sensors, reports and controller controls. |
| `monitoring.py` | Dashboard MQTT adapter, CSV logging and range requests. |
| `publisher.py` | Optional simulated pressure and pH; temperature comes from `simulator.py`. |
| `app.py` | Original desktop monitoring app. |
| `experiment.py` | Strategy comparison, offline. |
| `mqtt_common.py` | Shared connection code. |
| `test_control_logic.py`, `test_end_to_end.py`, `mutation_check.py` | Testing. |

## MQTT messages

| Topic | Sent by | Example | Retained |
|---|---|---|---|
| `biodigester/sensors/temperature` | sensor | `{"temperature": 36.42}` | no |
| `biodigester/sensors/pressure` | sensor / demo publisher | `{"pressure": 2.43}` | no |
| `biodigester/sensors/ph` | sensor / demo publisher | `{"ph": 7.02}` | no |
| `biodigester/heater/cmd` | controller | `{"action": "ON"}` | no |
| `biodigester/heater/state` | heater | `{"state": "ON"}` | yes |
| `biodigester/control/thresholds` | app | `{"low": 35.0, "high": 37.0}` | yes |
| `biodigester/control/status` | controller | `{"mode": "HEATING", "reason": "...", ...}` | yes |
| `biodigester/sim/fault` | app | `{"fault": "sensor_dropout"}` | no |
| `biodigester/sim/state` | simulator | `{"fault": "none", "ambient": 14.2, "speed": 60}` | yes |

The heater command is deliberately not retained and is re-sent every second.
A retained "ON" would be replayed by the broker even after the controller that
sent it had died.

## Before you quote any numbers

These values in `config.py` are placeholders. Replace them with your team's
real figures first, then re-run `experiment.py`.

- `DEFAULT_LOW_C`, `DEFAULT_HIGH_C`: the range to hold
- `SIM_SLURRY_KG`, `SIM_HEATER_W`, `SIM_UA_W_PER_K`, `SIM_HEATER_LAG_S`: the tank
- `SIM_AMBIENT_MEAN_C`, `SIM_AMBIENT_SWING_C`: the weather
- `SIM_SENSOR_NOISE_C`: the sensor

## Moving to the Raspberry Pi

1. Run Mosquitto, `controller.py` and `app.py` on the Pi (or the app on a
   laptop joined to the Pi's access point, with `BROKER_HOST` set to the Pi).
2. Replace `simulator.py` with a small script that reads the real sensor,
   publishes `biodigester/sensors/temperature`, obeys `biodigester/heater/cmd`,
   reports `biodigester/heater/state`, and switches the heater off if no
   command arrives for `HEATER_COMMAND_TIMEOUT_S`. Nothing else changes.
3. In `config.py`: set the timers to the real values given in the comments,
   and set `SHOW_SIM_PANEL = False`.

## Known limits

- The heater is treated as on/off only. There is no PID control.
- The temperature overshoots the top of the range slightly because the heater
  stays warm after it switches off. Set the range a little inside the range
  you actually need.
- There is one temperature sensor, so a sensor that is wrong but plausible
  cannot be detected.
- A heater that is stuck ON can be alarmed but not fixed by software. That
  needs a hardware cut-out.
- The app has been checked on a Linux virtual display, not yet on a Mac.

## If something goes wrong

- **"Cannot reach the MQTT broker"**: Mosquitto is not running. Start it.
- **`No module named tkinter`**: `brew install python-tk`.
- **The app says "Waiting for the controller"**: `controller.py` is not running.
- **Status keeps flipping to offline**: two controllers are running. Stop one.
