"""Demo pressure and pH for the dashboard; temperature comes from simulator.py.

These random walks are display examples, not a physical or chemical model.
"""
import random
import time

import config
from mqtt_common import connect_and_start, make_client, send

SIM = {"pressure": (2.0, 0.0, 5.0, 0.08), "ph": (7.0, 6.0, 8.0, 0.03)}


def main():
    client = make_client("biodigester-demo-extra-sensors")
    connect_and_start(client, "demo sensors")
    values = {k: spec[0] for k, spec in SIM.items()}
    print("Publishing simulated pressure and pH. Run simulator.py for temperature.")
    try:
        while True:
            for key, (_, low, high, step) in SIM.items():
                values[key] = min(high, max(low, values[key] + random.gauss(0, step)))
                send(client, config.SENSORS[key]["topic"], {key: round(values[key], 2)})
            time.sleep(2)
    except KeyboardInterrupt:
        pass
    finally:
        client.disconnect()
        client.loop_stop()


if __name__ == "__main__":
    main()
