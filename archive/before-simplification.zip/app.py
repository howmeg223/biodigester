"""
app.py - the optional original desktop monitor (Tkinter).

Run with:   python3 app.py

For the integrated browser monitor, run dashboard.py instead.
This window contains no control logic: it only shows what the controller reports
and sends it the range the user asks for. If this window is closed, the
digester keeps being regulated.

What it shows:
  * the latest temperature and the range being held
  * what the controller is doing and why, in plain words
  * a live graph: temperature, target range, heater-on periods, fault periods
  * a log of every change of state

What it can send:
  * a new target range (the controller checks it and may refuse it)
  * fault commands to the simulator, for testing and demonstrations

The MQTT client runs on its own thread, and Tkinter must only be touched from
the main thread, so messages are passed across in a queue and picked up by
tick() a few times a second.

Reading order: _build_window() creates the widgets; _start_mqtt() receives
messages; tick() processes them on the window thread. The remaining methods
update the displayed values, draw the graph or send a user request.
"""

import json
import math
import os
import queue
import time
import tkinter as tk
from collections import deque
from tkinter import font as tkfont
from tkinter import ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter

import config
from control_logic import MESSAGES
from mqtt_common import connected_ok, make_client, read_json

# Colours: blue for the measurement, green for the healthy range,
# amber for heat, red only when something is wrong.
BACKGROUND = "#F3F5F4"
INK = "#1F2A2E"
MUTED = "#5C6B70"
TEMPERATURE = "#1F5E8C"
RANGE_FILL = "#CFE6D4"
RANGE_TEXT = "#2E7D5B"
HEAT = "#E8A33D"            # fills on the graph
HEAT_TEXT = "#A85F00"       # the same idea, dark enough to read as text
PROBLEM = "#B3261E"
OFFLINE = "#8A9599"

MODE_TEXT = {
    "HEATING": ("Heating", HEAT_TEXT),
    "IDLE": ("Heater off", RANGE_TEXT),
    "FAULT": ("Fault: heating stopped", PROBLEM),
    "OFFLINE": ("Controller offline", OFFLINE),
    None: ("Waiting for the controller", OFFLINE),
}

FAULT_BUTTONS = [
    ("Silence sensor", "sensor_dropout"),
    ("Send nonsense reading", "sensor_bad"),
    ("Break heater", "heater_failure"),
    ("Clear fault", "none"),
]
FAULT_NAMES = {             # shown under the buttons
    "none": "For testing only. No fault injected.",
    "sensor_dropout": "Injected fault: the sensor is silent.",
    "sensor_bad": "Injected fault: the sensor is sending nonsense.",
    "heater_failure": "Injected fault: the heater ignores commands.",
}
FAULT_LOG = {               # written to the log
    "none": "Simulator: fault cleared.",
    "sensor_dropout": "Simulator: sensor silenced.",
    "sensor_bad": "Simulator: sensor sending nonsense.",
    "heater_failure": "Simulator: heater broken.",
}


class App:
    def __init__(self, root):
        self.root = root
        self.inbox = queue.Queue()          # messages from the MQTT thread

        # What we know so far.
        self.connected = False
        self.status = {}                    # latest status from the controller
        self.status_time = None
        self.heater_state = None            # what the heater itself reports
        self.sim = {}
        self.readings = deque()             # (time, temperature) for the graph
        self.modes = deque()                # (time, heater on?, fault?) for the graph
        self.last_logged = None
        self.last_note_id = None
        self.last_sim_fault = None
        self.range_edited = False           # is the user part-way through typing?
        self.shown_range = None             # the range last copied into the boxes
        self.last_draw = 0.0

        self._build_window()
        self._start_mqtt()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(250, self.tick)

    # ------------------------------------------------------------------ window
    def _build_window(self):
        root = self.root
        root.title("Biodigester monitor")
        root.geometry("920x760")
        root.minsize(780, 620)
        root.configure(bg=BACKGROUND)

        family = tkfont.nametofont("TkDefaultFont").actual("family")
        f_small = (family, 11)
        f_body = (family, 13)
        f_state = (family, 20, "bold")
        f_readout = (family, 52, "bold")

        def label(parent, **kw):
            kw.setdefault("bg", BACKGROUND)
            kw.setdefault("fg", INK)
            kw.setdefault("font", f_body)
            kw.setdefault("anchor", "w")
            kw.setdefault("justify", "left")
            return tk.Label(parent, **kw)

        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)

        # --- top: the reading on the left, the controller's state on the right
        top = tk.Frame(root, bg=BACKGROUND)
        top.grid(row=0, column=0, sticky="ew", padx=24, pady=(18, 6))
        top.columnconfigure(1, weight=1)

        reading = tk.Frame(top, bg=BACKGROUND)
        reading.grid(row=0, column=0, sticky="nw")
        label(reading, text="Digester temperature", fg=MUTED, font=f_small).pack(anchor="w")
        self.readout = label(reading, text="--.- °C", font=f_readout, fg=TEMPERATURE,
                             width=7)     # fixed width: the layout stays put
        self.readout.pack(anchor="w")
        self.range_line = label(reading, text="", fg=RANGE_TEXT)
        self.range_line.pack(anchor="w")

        state = tk.Frame(top, bg=BACKGROUND)
        state.grid(row=0, column=1, sticky="new", padx=(48, 0), pady=(14, 0))
        self.mode_label = label(state, text="Waiting for the controller",
                                font=f_state, fg=OFFLINE)
        self.mode_label.pack(anchor="w")
        self.reason_label = label(state, text="", fg=INK, wraplength=430)
        self.reason_label.pack(anchor="w", pady=(4, 0))
        self.alarm_label = label(state, text="", fg=PROBLEM, wraplength=430)
        self.alarm_label.pack(anchor="w", pady=(4, 0))
        self.heater_label = label(state, text="", fg=MUTED, font=f_small)
        self.heater_label.pack(anchor="w", pady=(4, 0))

        # --- middle: the graph
        self.figure = Figure(figsize=(9, 3.4), dpi=100, facecolor=BACKGROUND)
        self.axes = self.figure.add_subplot(111)
        self.figure.subplots_adjust(left=0.07, right=0.985, top=0.95, bottom=0.17)
        self.canvas = FigureCanvasTkAgg(self.figure, master=root)
        self.canvas.get_tk_widget().configure(bg=BACKGROUND, highlightthickness=0)
        self.canvas.get_tk_widget().grid(row=1, column=0, sticky="nsew", padx=16)
        self.speed_label = label(root, text="", fg=MUTED, font=f_small, wraplength=860)
        self.speed_label.grid(row=2, column=0, sticky="w", padx=24)

        # --- controls: the range, then the simulator faults underneath
        controls = tk.Frame(root, bg=BACKGROUND)
        controls.grid(row=3, column=0, sticky="ew", padx=24, pady=(12, 4))

        range_box = tk.Frame(controls, bg=BACKGROUND)
        range_box.grid(row=0, column=0, sticky="w")
        label(range_box, text="Target range", font=(family, 13, "bold")).grid(
            row=0, column=0, sticky="w", padx=(0, 18))
        self.low_var = tk.StringVar(value=f"{config.DEFAULT_LOW_C:g}")
        self.high_var = tk.StringVar(value=f"{config.DEFAULT_HIGH_C:g}")
        label(range_box, text="Heat below").grid(row=0, column=1, sticky="w")
        low_entry = ttk.Entry(range_box, textvariable=self.low_var, width=6, justify="right")
        low_entry.grid(row=0, column=2, padx=(6, 2))
        label(range_box, text="°C").grid(row=0, column=3, padx=(0, 14))
        label(range_box, text="Stop above").grid(row=0, column=4, sticky="w")
        high_entry = ttk.Entry(range_box, textvariable=self.high_var, width=6, justify="right")
        high_entry.grid(row=0, column=5, padx=(6, 2))
        label(range_box, text="°C").grid(row=0, column=6, padx=(0, 14))
        ttk.Button(range_box, text="Save range", command=self.save_range).grid(
            row=0, column=7)
        for entry in (low_entry, high_entry):
            entry.bind("<Key>", lambda event: setattr(self, "range_edited", True))
            entry.bind("<Return>", lambda event: self.save_range())
        self.range_note = label(range_box, text="", fg=MUTED, font=f_small)
        self.range_note.grid(row=1, column=1, columnspan=7, sticky="w", pady=(4, 0))

        if config.SHOW_SIM_PANEL:
            sim_box = tk.Frame(controls, bg=BACKGROUND)
            sim_box.grid(row=1, column=0, sticky="w", pady=(12, 0))
            label(sim_box, text="Simulator faults", font=(family, 13, "bold")).grid(
                row=0, column=0, sticky="w", padx=(0, 18))
            for column, (text, fault) in enumerate(FAULT_BUTTONS, start=1):
                ttk.Button(sim_box, text=text,
                           command=lambda f=fault: self.inject_fault(f)).grid(
                    row=0, column=column, padx=(0, 6))
            self.sim_note = label(sim_box, text="For testing only.", fg=MUTED, font=f_small)
            self.sim_note.grid(row=1, column=1, columnspan=4, sticky="w", pady=(4, 0))

        # --- bottom: the log and the connection line
        log_box = tk.Frame(root, bg=BACKGROUND)
        log_box.grid(row=4, column=0, sticky="ew", padx=24, pady=(10, 4))
        log_box.columnconfigure(0, weight=1)
        self.log = tk.Text(log_box, height=6, state="disabled", wrap="word",
                           bg="#FFFFFF", fg=INK, relief="flat", font=f_small,
                           padx=8, pady=6, highlightthickness=1,
                           highlightbackground="#D5DBD9")
        scroll = ttk.Scrollbar(log_box, command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.grid(row=0, column=0, sticky="ew")
        scroll.grid(row=0, column=1, sticky="ns")

        self.connection_label = label(root, text="", fg=MUTED, font=f_small)
        self.connection_label.grid(row=5, column=0, sticky="w", padx=24, pady=(0, 12))

    # ------------------------------------------------------------------ MQTT
    def _start_mqtt(self):
        self.client = make_client(f"biodigester-app-{os.getpid()}")

        def on_connect(client, userdata, flags, reason_code, *extra):
            if connected_ok(reason_code):
                client.subscribe(f"{config.ROOT}/#", qos=1)
                self.inbox.put(("connected", None, None))

        def on_disconnect(client, userdata, *extra):
            self.inbox.put(("disconnected", None, None))

        def on_message(client, userdata, msg):
            self.inbox.put(("message", msg.topic, read_json(msg)))

        self.client.on_connect = on_connect
        self.client.on_disconnect = on_disconnect
        self.client.on_message = on_message
        # connect_async + loop_start keeps trying in the background, so the
        # window opens even if the broker is not running yet.
        self.client.connect_async(config.BROKER_HOST, config.BROKER_PORT,
                                  keepalive=config.KEEPALIVE_S)
        self.client.loop_start()

    def publish(self, topic, payload, retain=False):
        if not self.connected:
            return False
        self.client.publish(topic, json.dumps(payload), qos=1, retain=retain)
        return True

    # ------------------------------------------------------------------ actions
    def save_range(self):
        try:
            low, high = float(self.low_var.get()), float(self.high_var.get())
        except ValueError:
            self.range_note.config(
                text="Enter both temperatures as numbers, for example 35 and 37.", fg=PROBLEM)
            return
        # The app does not judge the range. The controller does, and replies.
        if self.publish(config.TOPIC_THRESHOLDS, {"low": low, "high": high}, retain=True):
            self.range_edited = False
            self.range_note.config(text="Sent. Waiting for the controller to confirm.", fg=MUTED)
        else:
            self.range_note.config(
                text="Not connected to the broker, so nothing was sent.", fg=PROBLEM)

    def inject_fault(self, fault):
        if not self.publish(config.TOPIC_SIM_FAULT, {"fault": fault}):
            self.sim_note.config(text="Not connected to the broker, so nothing was sent.")

    def add_to_log(self, text):
        stamp = time.strftime("%H:%M:%S")
        self.log.config(state="normal")
        self.log.insert("end", f"{stamp}  {text}\n")
        self.log.see("end")
        self.log.config(state="disabled")

    # ------------------------------------------------------------------ incoming
    def handle(self, kind, topic, data):
        now = time.monotonic()
        if kind == "connected":
            self.connected = True
            self.add_to_log("Connected to the broker.")
        elif kind == "disconnected":
            if self.connected:
                self.add_to_log("Lost the connection to the broker. Trying to reconnect.")
            self.connected = False
        elif data is None:
            return                                  # not JSON: nothing to show
        elif topic == config.TOPIC_TEMPERATURE:
            try:
                value = float(data.get("temperature"))
            except (TypeError, ValueError):
                return
            # Only believable values go on the graph; the controller reports the rest.
            if math.isfinite(value) and config.PLAUSIBLE_MIN_C <= value <= config.PLAUSIBLE_MAX_C:
                self.readings.append((now, value))
        elif topic == config.TOPIC_STATUS:
            self.status, self.status_time = data, now
            # For the graph: is the heater on? Prefer the heater's own report
            # over the command, so a broken heater does not show as heating.
            heater_on = (self.heater_state == "ON" if self.heater_state is not None
                         else bool(data.get("heating")))
            self.modes.append((now, heater_on, data.get("mode") == "FAULT"))
            self._log_status_changes(data)
        elif topic == config.TOPIC_HEATER_STATE:
            self.heater_state = data.get("state")
        elif topic == config.TOPIC_SIM_STATE:
            self.sim = data
            if data.get("fault") != self.last_sim_fault:
                if self.last_sim_fault is not None:
                    self.add_to_log(FAULT_LOG.get(data.get("fault"), "Simulator changed."))
                self.last_sim_fault = data.get("fault")

    def _log_status_changes(self, status):
        """Write a log line only when the controller's situation changes."""
        mode = status.get("mode")
        alarms = tuple(status.get("alarms") or [])
        summary = (mode, status.get("fault"), alarms)
        if summary != self.last_logged:
            self.last_logged = summary
            line = f"{MODE_TEXT.get(mode, MODE_TEXT[None])[0]}. {status.get('reason', '')}"
            if alarms:
                line += "  Alarm: " + " ".join(MESSAGES.get(a, a) for a in alarms)
            self.add_to_log(line)

        note_id = status.get("note_id")
        if note_id is not None and note_id != self.last_note_id:
            if self.last_note_id is not None or status.get("note"):
                rejected = "rejected" in status.get("note", "")
                self.range_note.config(text=status.get("note", ""),
                                       fg=PROBLEM if rejected else RANGE_TEXT)
                if self.last_note_id is not None:
                    self.add_to_log(status.get("note", ""))
            self.last_note_id = note_id

    # ------------------------------------------------------------------ refresh
    def tick(self):
        while True:
            try:
                self.handle(*self.inbox.get_nowait())
            except queue.Empty:
                break
        now = time.monotonic()

        # Forget anything older than the graph shows.
        for series in (self.readings, self.modes):
            while series and now - series[0][0] > config.APP_HISTORY_S:
                series.popleft()

        self._refresh_text(now)
        if now - self.last_draw >= 1.0:
            self.last_draw = now
            self._draw_graph(now)
        self.root.after(250, self.tick)

    def _refresh_text(self, now):
        status = self.status
        # A controller that has gone quiet is treated as not there.
        quiet = self.status_time is None or now - self.status_time > 5 * config.CONTROL_PERIOD_S
        mode = None if (quiet and status.get("mode") != "OFFLINE") else status.get("mode")
        if not self.connected:
            mode = None

        text, colour = MODE_TEXT.get(mode, MODE_TEXT[None])
        self.mode_label.config(text=text, fg=colour)

        if mode is None:
            self.reason_label.config(text="No status is arriving. Is controller.py running?"
                                     if self.connected else "")
            self.alarm_label.config(text="")
        else:
            self.reason_label.config(text=status.get("reason", ""))
            self.alarm_label.config(text="\n".join(status.get("alarm_text") or []))

        fresh = self.readings and now - self.readings[-1][0] <= 3 * config.SENSOR_PERIOD_S
        if fresh:
            self.readout.config(text=f"{self.readings[-1][1]:.1f} °C", fg=TEMPERATURE)
        else:
            self.readout.config(text="--.- °C", fg=OFFLINE)

        if "low" in status:
            self.range_line.config(
                text=f"Holding {status['low']:g} to {status['high']:g} °C")
            # Copy the controller's range into the boxes when it changes,
            # unless the user is part-way through typing a new one.
            current = (status["low"], status["high"])
            if current != self.shown_range and not self.range_edited:
                self.low_var.set(f"{status['low']:g}")
                self.high_var.set(f"{status['high']:g}")
                self.shown_range = current
        self.heater_label.config(
            text="" if self.heater_state is None
            else f"The heater reports it is {self.heater_state.lower()}.")

        if config.SHOW_SIM_PANEL and self.sim:
            self.sim_note.config(text=FAULT_NAMES.get(self.sim.get("fault"), ""))
        speed = self.sim.get("speed")
        if speed and speed != 1:
            self.speed_label.config(
                text=f"Simulated digester, running {speed:g} times faster than real time. "
                     f"Simulated outdoor temperature: {self.sim.get('ambient', '?')} °C.")

        if self.connected:
            self.connection_label.config(
                text=f"Connected to the broker at {config.BROKER_HOST}:{config.BROKER_PORT}.",
                fg=MUTED)
        else:
            self.connection_label.config(
                text=f"Cannot reach the broker at {config.BROKER_HOST}:{config.BROKER_PORT}. "
                     "Start Mosquitto and this window will connect by itself.", fg=PROBLEM)

    def _draw_graph(self, now):
        ax = self.axes
        ax.clear()
        ax.set_facecolor("#FFFFFF")
        low = self.status.get("low", config.DEFAULT_LOW_C)
        high = self.status.get("high", config.DEFAULT_HIGH_C)

        ax.axhspan(low, high, color=RANGE_FILL, zorder=0, label="Target range")

        # Temperature, with a break in the line wherever readings went missing.
        xs, ys, previous = [], [], None
        for t, value in self.readings:
            if previous is not None and t - previous > 3 * config.SENSOR_PERIOD_S:
                xs.append(t - now)
                ys.append(math.nan)
            xs.append(t - now)
            ys.append(value)
            previous = t
        ax.plot(xs, ys, color=TEMPERATURE, linewidth=2, label="Temperature")

        # Along the bottom: when the heater was on. Full height: faults.
        if self.modes:
            mx = [t - now for t, _, _ in self.modes]
            along_x = ax.get_xaxis_transform()      # x in seconds, y from 0 to 1
            ax.fill_between(mx, 0, 0.05, where=[h for _, h, _ in self.modes], step="post",
                            color=HEAT, linewidth=0, transform=along_x, label="Heater on")
            ax.fill_between(mx, 0, 1, where=[f for _, _, f in self.modes], step="post",
                            color=PROBLEM, alpha=0.13, linewidth=0, transform=along_x,
                            label="Fault")

        values = [v for v in ys if not math.isnan(v)]
        bottom = min([low - 1.0] + [v - 0.3 for v in values])
        top = max([high + 1.0] + [v + 0.3 for v in values])
        bottom -= 0.10 * (top - bottom)         # room for the heater strip
        ax.set_ylim(bottom, top)
        ax.set_xlim(-config.APP_HISTORY_S, 0)
        ax.xaxis.set_major_formatter(FuncFormatter(
            lambda x, _: "now" if abs(x) < 0.5 else f"{-x / 60:g} min ago"))
        ax.set_xticks(range(-int(config.APP_HISTORY_S), 1, 60))
        ax.set_ylabel("°C", color=MUTED)
        ax.tick_params(colors=MUTED, labelsize=9)
        for side in ("top", "right"):
            ax.spines[side].set_visible(False)
        for side in ("left", "bottom"):
            ax.spines[side].set_color("#C9D1CF")
        ax.grid(axis="y", color="#E3E8E6", linewidth=0.8)
        ax.legend(loc="upper left", ncol=4, fontsize=9, frameon=False,
                  labelcolor=MUTED, borderaxespad=0.2)
        self.canvas.draw_idle()

    # ------------------------------------------------------------------ closing
    def close(self):
        try:
            self.client.loop_stop()
            self.client.disconnect()
        except Exception:
            pass
        self.root.destroy()


if __name__ == "__main__":
    window = tk.Tk()
    App(window)
    window.mainloop()
