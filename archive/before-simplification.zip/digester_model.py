"""
digester_model.py - a simple thermal model of the digester.

This stands in for the real tank while there is no hardware. Like
control_logic.py it is plain Python with no MQTT, so the MQTT simulator, the
offline experiment and the tests all use exactly the same physics.

The model is one energy balance:

    dT/dt = (Q_heat - Q_loss) / (M * c_p)        Q_loss = UA * (T - T_ambient)

Heat in from the heater, heat out through the walls, divided by how much
energy it takes to warm the slurry by one degree. This is the same first-order
balance used for a small digester in Ikegwuonu et al. (2025), J. Energy
Technology and Environment 7(3), sections 2.3.2 and 2.3.3.

One addition: a heater lag. A real heater keeps giving off heat for a while
after it is switched off, which is what makes the temperature overshoot the
top of the band. Setting heater_lag_s to 0 removes it.
"""

import math

WATER_CP = 4186.0   # J/(kg.K). Slurry is treated as water, as in the paper above.


class DigesterModel:
    def __init__(self, temp_c, slurry_kg, heater_w, ua_w_per_k, heater_lag_s=0.0):
        self.temp_c = temp_c                # slurry temperature right now
        self.slurry_kg = slurry_kg
        self.heater_w = heater_w            # heater power when fully on
        self.ua_w_per_k = ua_w_per_k        # heat lost per degree above ambient
        self.heater_lag_s = heater_lag_s
        self.heat_w = 0.0                   # heat actually reaching the slurry

    def step(self, dt_s, heater_on, ambient_c):
        """Advance the model by dt_s seconds and return the new temperature."""
        if heater_on:
            target_w = self.heater_w
        else:
            target_w = 0.0

        # Heater lag: delivered heat drifts towards the target instead of jumping.
        if self.heater_lag_s > 0:
            # This fraction says how far the heater moves towards its target
            # during this step. A longer lag means a smaller change.
            response_fraction = 1.0 - math.exp(-dt_s / self.heater_lag_s)
            self.heat_w += (target_w - self.heat_w) * response_fraction
        else:
            self.heat_w = target_w

        heat_loss_w = self.ua_w_per_k * (self.temp_c - ambient_c)
        net_heat_w = self.heat_w - heat_loss_w
        heat_capacity = self.slurry_kg * WATER_CP  # energy needed for a 1 °C rise
        temperature_change = net_heat_w / heat_capacity * dt_s
        self.temp_c += temperature_change
        return self.temp_c


def ambient_temperature(t_s, mean_c, swing_c):
    """Outdoor temperature at simulated time t_s: a smooth 24-hour day/night cycle."""
    seconds_per_day = 86400.0
    day_cycle_angle = 2 * math.pi * t_s / seconds_per_day
    return mean_c + swing_c * math.sin(day_cycle_angle)
