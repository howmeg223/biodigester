"""MQTT and CSV adapter for the browser dashboard; no heater control here."""
import csv
import json
import math
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

import config
from control_logic import Settings, check_thresholds
from mqtt_common import connected_ok, make_client


class Monitor:
    def __init__(self, log_file=config.LOG_FILE):
        self.log_file = Path(log_file)
        self.lock = threading.RLock()
        self.latest = {}
        self.messages = {}
        self.connected = False
        self.client = None
        self.sensor_topics = {s["topic"]: k for k, s in config.SENSORS.items()}

    def ensure_log(self):
        with self.lock:
            self.log_file.parent.mkdir(parents=True, exist_ok=True)
            if not self.log_file.exists() or self.log_file.stat().st_size == 0:
                with self.log_file.open("w", newline="", encoding="utf-8") as f:
                    csv.writer(f).writerow(["timestamp", "sensor", "value"])

    def handle_message(self, topic, payload, retained=False):
        try:
            data = json.loads(payload.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return
        now = time.monotonic()
        with self.lock:
            if topic in self.sensor_topics:
                key = self.sensor_topics[topic]
                raw = data.get(key) if isinstance(data, dict) else data
                if isinstance(raw, bool):
                    return
                try:
                    value = float(raw)
                except (ValueError, TypeError, OverflowError):
                    return
                if not math.isfinite(value):
                    return
                stamp = datetime.now()
                self.latest[key] = (value, stamp, retained, now)
                if not retained:
                    self.ensure_log()
                    with self.log_file.open("a", newline="", encoding="utf-8") as f:
                        csv.writer(f).writerow([stamp.isoformat(timespec="seconds"), key, value])
            elif topic in (config.TOPIC_STATUS, config.TOPIC_HEATER_STATE, config.TOPIC_SIM_STATE):
                if not isinstance(data, dict):
                    return
                if topic == config.TOPIC_STATUS:
                    if data.get("mode") not in ("HEATING", "IDLE", "FAULT", "OFFLINE"):
                        return
                    for key in ("low", "high"):
                        if key in data and (isinstance(data[key], bool) or
                                            not isinstance(data[key], (int, float)) or
                                            not math.isfinite(data[key])):
                            return
                    if not isinstance(data.get("reason", ""), str) or not isinstance(data.get("note", ""), str):
                        return
                    alarms = data.get("alarm_text", [])
                    if not isinstance(alarms, list) or not all(isinstance(a, str) for a in alarms):
                        return
                elif topic == config.TOPIC_HEATER_STATE and data.get("state") not in ("ON", "OFF"):
                    return
                self.messages[topic] = (data, now, retained)

    def snapshot(self):
        with self.lock:
            return dict(self.latest), dict(self.messages), self.connected

    def controller_status(self):
        _, messages, connected = self.snapshot()
        entry = messages.get(config.TOPIC_STATUS)
        if not entry:
            return {"mode": "OFFLINE", "reason": "Waiting for the controller."}
        data, received, retained = entry
        if not connected or time.monotonic() - received > config.STALE_AFTER_S:
            return {"mode": "OFFLINE", "reason": "No live controller status. Check the controller and broker."}
        if retained and data.get("mode") != "OFFLINE":
            return {"mode": "OFFLINE", "reason": "Saved controller status received; waiting for a live update."}
        return dict(data)

    def start(self):
        self.ensure_log()
        client = make_client(f"biodigester-dashboard-{uuid.uuid4().hex[:8]}")

        def on_connect(c, userdata, flags, reason_code, *extra):
            with self.lock:
                self.connected = connected_ok(reason_code)
            if self.connected:
                for topic in (*self.sensor_topics, config.TOPIC_STATUS,
                              config.TOPIC_HEATER_STATE, config.TOPIC_SIM_STATE):
                    c.subscribe(topic, qos=1)

        def on_disconnect(*args):
            with self.lock:
                self.connected = False

        client.on_connect = on_connect
        client.on_disconnect = on_disconnect
        client.on_message = lambda c, u, m: self.handle_message(m.topic, m.payload, bool(m.retain))
        self.client = client
        client.connect_async(config.BROKER_HOST, config.BROKER_PORT, config.KEEPALIVE_S)
        client.loop_start()

    def stop(self):
        if self.client:
            self.client.disconnect()
            self.client.loop_stop()

    def publish(self, topic, data, retain=False):
        if not self.client or not self.client.is_connected():
            return "Not connected to the broker. Nothing was sent."
        result = self.client.publish(topic, json.dumps(data), qos=1, retain=retain)
        if result.rc != 0:
            return "Could not send the request. Try again after reconnecting."
        return None

    def set_range(self, low, high):
        problem = check_thresholds(low, high, Settings(
            threshold_min_c=config.THRESHOLD_MIN_C,
            threshold_max_c=config.THRESHOLD_MAX_C, min_band_c=config.MIN_BAND_C))
        if problem:
            return problem
        if self.controller_status().get("mode") == "OFFLINE":
            return "Wait for a live controller before changing the range."
        problem = self.publish(config.TOPIC_THRESHOLDS,
                               {"low": float(low), "high": float(high)}, retain=True)
        return problem or "Range request sent. Check the active range and controller reply below."

    def set_fault(self, fault):
        if not config.SHOW_SIM_PANEL:
            return "Simulator controls are disabled."
        if fault not in ("sensor_dropout", "sensor_bad", "heater_failure", "none"):
            return "Unknown simulator fault."
        problem = self.publish(config.TOPIC_SIM_FAULT, {"fault": fault})
        return problem or "Simulator request sent."
