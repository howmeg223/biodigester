# Reading the biodigester code

Start with `config.py`, then `control_logic.py`, then `controller.py`.
The first file holds settings, the second makes heating decisions, and the
third receives and sends messages. `simulator.py` supplies a pretend tank so
you can try the system before connecting hardware.

## How the programs fit together

```text
simulator.py -- temperature --> controller.py -- heater command --> simulator.py
      |                              |
      +------- readings -------------+----- status ----> dashboard.py

dashboard.py -- requested temperature range --> controller.py
```

Every arrow passes through the MQTT broker. The broker is a message delivery
service, such as Mosquitto. A topic is an address such as
`biodigester/sensors/temperature`. Programs subscribe to addresses they want
to receive and publish messages to addresses they want to send to.

The controller runs independently of the dashboard. The dashboard displays
readings and sends requests; the controller decides whether heating is allowed.

## The basic heating rule

The default target range is 35–37 °C. With the `hysteresis` strategy:

| Reading | Requested heater state |
|---|---|
| Below 35 °C | ON |
| Between 35 and 37 °C, including the boundaries | Keep the previous state |
| Above 37 °C | OFF |

Keeping the previous state inside the range prevents rapid switching when
readings move slightly. This rule is `decide_hysteresis()` in `control_logic.py`.
The `simple` strategy instead switches around the midpoint, 36 °C.

`Regulator.update()` adds checks around the basic rule. Missing, stale or
invalid readings force heating off. The minimum on/off timers can delay a
normal switch. A temperature far above the target range overrides the timer
and turns heating off immediately. Heater feedback can raise an alarm if the
heater does not follow its command.

## Try a decision without MQTT or hardware

From this project folder, run `python3` to open Python, then paste:

```python
from control_logic import Regulator, Settings, Thresholds

target_range = Thresholds(low=35, high=37)
# Set the waiting times to zero for this small example only.
settings = Settings(min_on_s=0, min_off_s=0)
regulator = Regulator(target_range, settings)

readings = [34, 36, 38, 36, 34]
for step_number, temperature in enumerate(readings):
    decision = regulator.update(
        now=step_number * 10,
        temp_c=temperature,
        reading_age_s=0,
    )
    print(temperature, decision.mode, decision.reason)
```

The modes are `HEATING`, `HEATING`, `IDLE`, `IDLE`, `HEATING`.
The two readings of 36 °C give different results because the regulator
remembers whether it was already heating. Type `exit()` to leave Python.

## Following controller.py

Read `main()` in numbered order:

1. Read terminal arguments and create a regulator with settings from `config.py`.
2. Create an MQTT client and define the message handlers.
3. Connect to the broker and start receiving messages.
4. Repeat: read the latest temperature, calculate its age, make a decision,
   send a heater command, send dashboard status, then wait.
5. On exit, send OFF and announce that the controller has stopped.

`on_connect()` and `on_message()` are **callbacks**: MQTT calls these functions
when a connection or message arrives. They run in a background thread. The
main loop runs at the same time, so `with lock:` prevents both threads from
changing shared values at once. The callback arguments come from MQTT;
`*extra` accepts additional arguments supplied by different library versions.

`time.monotonic()` measures elapsed time. It keeps moving forward even if the
computer's calendar clock changes. That makes it suitable for checking how
old a reading is and how long the heater has been on.

## Common Python names in these files

| Code | Meaning |
|---|---|
| `None` | No value is available yet |
| `True` / `False` | Yes / no; heater on / off |
| `@dataclass` | Creates an object for named values, such as `Thresholds(low=35, high=37)` |
| `self` | The object whose method is running; each regulator remembers its own state |
| `regulator.th` | The regulator's thresholds (target range) |
| `math.nan` | “Not a number”; used to mark a broken temperature reading |
| `try` / `except` | Attempt something and handle a failure |
| `finally` | Cleanup that runs when execution leaves the `try` block |
| `if __name__ == "__main__":` | Start the program when run directly; do not start it when imported |
| `f"{value:g}"` | Put a value into text without unnecessary trailing zeros |

MQTT messages use JSON: `{"temperature": 36.42}` is text representing a small
dictionary. `mqtt_common.py` converts between that text and Python dictionaries.
A **retained** message is saved by the broker for future subscribers. Status
and target ranges are saved; heater commands are sent fresh on every cycle.
The simulator turns its heater off if commands stop arriving.

## The other original files

| File | When to read it |
|---|---|
| `simulator.py` | To see heater commands change a simulated tank and test faults |
| `digester_model.py` | To see how heater power and heat loss change temperature |
| `mqtt_common.py` | To understand connection, message reading and message sending |
| `experiment.py` | To compare strategies offline and generate a graph |
| `test_control_logic.py` | To see examples of expected control behavior |
| `test_end_to_end.py` | To check programs communicating through a running broker |
| `mutation_check.py` | Optional: checks whether tests catch deliberate mistakes |
| `app.py` | Optional: the original desktop monitor; `dashboard.py` is the browser monitor |

In the simulator, real elapsed seconds are multiplied by `SIM_SPEED` to get
simulated seconds. `digester_model.py` then calculates heat in minus heat out
and converts it to a temperature change. Tank values in `config.py` are
placeholders; the experiment compares strategies using those same values.

Use the setup and terminal commands in [README.md](README.md) to run the full
system. Change project settings in `config.py`; the controller and simulator
load those settings when they start. Use **Save range** on the dashboard to
request a range change while the controller is running.
