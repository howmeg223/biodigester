"""
experiment.py - compare control strategies on the simulated digester.

Run with:   python3 experiment.py

No MQTT and no waiting: two simulated days per strategy run in about a second.
It uses the SAME Regulator as the live controller and the SAME DigesterModel as
the MQTT simulator, so what is measured here is the code that actually runs.

Strategies compared:
  1. Simple threshold        one setpoint, no hold zone (the baseline)
  2. Hysteresis              two thresholds with a hold zone
  3. Hysteresis + min time   as 2, plus a minimum on/off time (the live setup)

Every strategy sees the same weather and the same sensor noise.

It prints a table for all three and saves experiment_results.png, which plots
the baseline (1) against the live setup (3): two days of temperature on the
left, and one hour of heater on/off on the right.

The digester numbers in config.py are PLACEHOLDERS, so treat the figures this
prints as a comparison between strategies, not as predictions for your tank.
"""

import random

import matplotlib
matplotlib.use("Agg")           # draw straight to a file, no window needed
import matplotlib.pyplot as plt

import config
from control_logic import Regulator, Settings, Thresholds
from digester_model import DigesterModel, ambient_temperature

HOURS = 48
STEP_S = 10.0            # one sensor reading and one decision every 10 simulated seconds
REAL_MIN_ON_OFF_S = 300.0   # a realistic minimum on/off time: 5 minutes

STRATEGIES = [
    ("Simple threshold", Settings(strategy="simple", min_on_s=0, min_off_s=0)),
    ("Hysteresis", Settings(strategy="hysteresis", min_on_s=0, min_off_s=0)),
    ("Hysteresis + min on/off time", Settings(strategy="hysteresis",
                                              min_on_s=REAL_MIN_ON_OFF_S,
                                              min_off_s=REAL_MIN_ON_OFF_S)),
]


def run(settings, seed=1):
    """Run one strategy. Returns lists of time (hours), temperature, heater state."""
    target_range = Thresholds(config.DEFAULT_LOW_C, config.DEFAULT_HIGH_C)
    regulator = Regulator(target_range, settings)
    model = DigesterModel(temp_c=target_range.midpoint,
                          slurry_kg=config.SIM_SLURRY_KG,
                          heater_w=config.SIM_HEATER_W,
                          ua_w_per_k=config.SIM_UA_W_PER_K,
                          heater_lag_s=config.SIM_HEATER_LAG_S)
    noise = random.Random(seed)          # same seed = same noise for every strategy

    hours = []
    temperatures = []
    heater_states = []
    number_of_steps = int(HOURS * 3600 / STEP_S)
    for step_number in range(number_of_steps):
        now = step_number * STEP_S
        reading = model.temp_c + noise.gauss(0, config.SIM_SENSOR_NOISE_C)
        decision = regulator.update(now, reading, reading_age_s=0.0)
        ambient = ambient_temperature(now, config.SIM_AMBIENT_MEAN_C,
                                      config.SIM_AMBIENT_SWING_C)
        model.step(STEP_S, decision.heating, ambient)
        hours.append(now / 3600)
        temperatures.append(model.temp_c)
        heater_states.append(decision.heating)
    return hours, temperatures, heater_states


def measure(temps, heater):
    """Turn one run into the numbers worth comparing."""
    low, high = config.DEFAULT_LOW_C, config.DEFAULT_HIGH_C
    number_of_readings = len(temps)
    switches = 0
    # Compare each heater state with the one immediately before it.
    for index in range(1, len(heater)):
        if heater[index] != heater[index - 1]:
            switches += 1

    readings_in_range = 0
    for temperature in temps:
        if low <= temperature <= high:
            readings_in_range += 1

    heater_on_readings = 0
    for heating in heater:
        if heating:
            heater_on_readings += 1
    on_fraction = heater_on_readings / number_of_readings
    return {
        "in_band_pct": 100 * readings_in_range / number_of_readings,
        "min_c": min(temps),
        "max_c": max(temps),
        "switches_per_day": switches / (HOURS / 24),
        "on_pct": 100 * on_fraction,
        "kwh_per_day": on_fraction * config.SIM_HEATER_W * 24 / 1000,
    }


def main():
    results = []
    for name, settings in STRATEGIES:
        hours, temps, heater = run(settings)
        results.append((name, hours, temps, heater, measure(temps, heater)))

    # ---- table ----
    print(f"\n{HOURS} simulated hours, band {config.DEFAULT_LOW_C}-{config.DEFAULT_HIGH_C} °C, "
          f"one reading every {STEP_S:.0f} s\n")
    print(f"{'Strategy':<30}{'In band':>9}{'Min °C':>9}{'Max °C':>9}"
          f"{'Switches/day':>14}{'Heater on':>11}{'kWh/day':>9}")
    for name, _, _, _, m in results:
        print(f"{name:<30}{m['in_band_pct']:>8.1f}%{m['min_c']:>9.2f}{m['max_c']:>9.2f}"
              f"{m['switches_per_day']:>14.0f}{m['on_pct']:>10.1f}%{m['kwh_per_day']:>9.2f}")

    # Rows 2 and 3 are often identical, which is worth saying out loud.
    if results[1][4]["switches_per_day"] == results[2][4]["switches_per_day"]:
        print("\nRows 2 and 3 match because a natural heating cycle is much longer than the "
              f"{REAL_MIN_ON_OFF_S / 60:.0f}-minute\nminimum on/off time. The timer is a backstop "
              "for abnormal conditions, not part of normal running.")

    # ---- figure: baseline against the live setup ----
    low, high = config.DEFAULT_LOW_C, config.DEFAULT_HIGH_C
    shown = [results[0], results[2]]

    # Close-up window: one hour starting 10 minutes before the live setup
    # switches its heater on for the first time after hour 12.
    _, hours, _, live_heater, _ = results[2]
    first = len(hours) // 4  # fallback if no switch is found after hour 12
    for index in range(1, len(hours)):
        switched_on = live_heater[index] and not live_heater[index - 1]
        if hours[index] >= 12 and switched_on:
            first = index
            break
    start = max(0, first - int(600 / STEP_S))
    stop = min(len(hours), start + int(3600 / STEP_S))

    fig, axes = plt.subplots(len(shown), 2, figsize=(12, 6.2),
                             gridspec_kw={"width_ratios": [3, 1.25]})
    for (left, right), (name, hours, temps, heater, m) in zip(axes, shown):
        left.axhspan(low, high, color="#CFE6D4", zorder=0, label="Target range")
        left.axvspan(hours[start], hours[stop - 1], color="#000000", alpha=0.07,
                     label="Hour shown on the right")
        left.plot(hours, temps, color="#1F5E8C", linewidth=1.3, label="Digester temperature")
        left.set_ylim(low - 0.5, high + 0.6)
        left.set_ylabel("°C")
        left.set_title(f"{name}:  {m['in_band_pct']:.1f}% of time in range,  "
                       f"{m['min_c']:.2f} to {m['max_c']:.2f} °C", loc="left", fontsize=11)
        left.grid(alpha=0.25)

        minutes = [(h - hours[start]) * 60 for h in hours[start:stop]]
        right.fill_between(minutes, 0, [1 if on else 0 for on in heater[start:stop]],
                           step="post", color="#E8A33D", linewidth=0)
        right.set_ylim(-0.08, 1.25)
        right.set_yticks([0, 1])
        right.set_yticklabels(["off", "on"])
        right.set_xlim(0, 60)
        right.set_title(f"Heater:  {m['switches_per_day']:.0f} switches per day",
                        loc="left", fontsize=11)
        right.grid(alpha=0.25)

    axes[0][0].legend(loc="upper right", ncol=3, fontsize=9, frameon=False)
    axes[-1][0].set_xlabel("Simulated hours")
    axes[-1][1].set_xlabel("Minutes (one hour, close up)")
    fig.suptitle("Control strategies on the simulated digester (placeholder tank values)",
                 x=0.01, ha="left", fontsize=13)
    fig.tight_layout()
    fig.savefig("experiment_results.png", dpi=130)
    print("\nSaved experiment_results.png")


if __name__ == "__main__":
    main()
