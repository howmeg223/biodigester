"""
mutation_check.py - are the tests any good?  (optional extra)

Run with:   python3 mutation_check.py

A passing test suite only proves something if it would FAIL when the code is
wrong. This script checks that, using mutation testing: it makes one small
deliberate mistake in control_logic.py (a "mutant"), runs the unit tests, and
records whether they noticed. A mutant the tests catch is "killed". One they
miss "survives" and points at a gap in the tests.

It works on a temporary copy, so your real files are never changed.

Two mutants are expected to survive because they are EQUIVALENT: the change
cannot alter the program's behaviour, so no test could ever catch it. They
are marked below with the reason.
"""

import pathlib
import shutil
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).parent
FILES = ["control_logic.py", "digester_model.py", "test_control_logic.py"]

# (description, original text, mutated text, why it is equivalent or None)
MUTANTS = [
    ("on/off rule: '<' becomes '<=' at the low threshold",
     "    if temp_c < th.low:\n        return True       # too cold: heat",
     "    if temp_c <= th.low:\n        return True       # too cold: heat", None),
    ("on/off rule: '>' becomes '>=' at the high threshold",
     "    if temp_c > th.high:\n        return False      # warm enough: stop",
     "    if temp_c >= th.high:\n        return False      # warm enough: stop", None),
    ("on/off rule: inside the band always means off",
     "    return heating        # inside the band",
     "    return False        # inside the band", None),
    ("simple rule: '<' becomes '<='",
     "    return temp_c < setpoint",
     "    return temp_c <= setpoint", None),
    ("stale-reading check removed",
     "    if age_s > settings.stale_after_s:\n        return SENSOR_STALE\n",
     "", None),
    ("stale-reading check: '>' becomes '>='",
     "    if age_s > settings.stale_after_s:",
     "    if age_s >= settings.stale_after_s:", None),
    ("not-a-number check removed",
     "    if not math.isfinite(temp_c):\n        return SENSOR_BAD_VALUE\n",
     "", None),
    ("upper plausible limit ignored",
     " or temp_c > settings.plausible_max_c:",
     ":", None),
    ("a fault no longer switches the heater off",
     "        if fault:\n            self._switch(False, now)\n",
     "        if fault:\n", None),
    ("a fault reports the stored heater state instead of False",
     'return Decision(False, "FAULT", fault, alarms, MESSAGES[fault])',
     'return Decision(self.heating, "FAULT", fault, alarms, MESSAGES[fault])',
     "self._switch(False, now) has just set self.heating to False, so both are False"),
    ("minimum on/off time ignored",
     "        return time_in_current_state >= minimum_duration",
     "        return True", None),
    ("minimum on time and minimum off time swapped",
     "        if self.heating:\n"
     "            minimum_duration = self.settings.min_on_s\n"
     "        else:\n"
     "            minimum_duration = self.settings.min_off_s\n",
     "        if self.heating:\n"
     "            minimum_duration = self.settings.min_off_s\n"
     "        else:\n"
     "            minimum_duration = self.settings.min_on_s\n", None),
    ("far-too-hot override removed",
     "        elif not requested_heating and TEMP_HIGH in alarms:\n"
     "            self._switch(False, now)\n"
     '            reason = "Far above the target range: heating forced off."\n',
     "", None),
    ("low alarm line on the wrong side of the threshold",
     "self.th.low - settings.alarm_margin_c",
     "self.th.low + settings.alarm_margin_c", None),
    ("threshold order check removed",
     "    if low >= high:\n"
     '        return "The lower temperature must be below the upper one."\n',
     "",
     "the minimum-width check below it also rejects low >= high"),
    ("minimum band width check disabled",
     "    if high - low < settings.min_band_c:",
     "    if False:", None),
    ("rejected thresholds applied anyway",
     "        if problem is None:\n            self.th",
     "        if True:\n            self.th", None),
    ("heater alarm raised without waiting for the timeout",
     "        if now - self._mismatch_since >= self.settings.actuator_timeout_s:",
     "        if True:", None),
    ("strategy setting ignored",
     '        if settings.strategy == "simple":',
     "        if False:", None),
]


def tests_fail(folder):
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider",
         "test_control_logic.py"],
        cwd=folder, capture_output=True, text=True)
    return result.returncode != 0


def main():
    original = (HERE / "control_logic.py").read_text()
    with tempfile.TemporaryDirectory() as temp:
        folder = pathlib.Path(temp)
        for name in FILES:
            shutil.copy(HERE / name, folder / name)

        if tests_fail(folder):
            sys.exit("The tests fail before any mutation. Fix that first.")

        killed = survived_equivalent = survived_real = 0
        for description, before, after, equivalent_because in MUTANTS:
            if original.count(before) != 1:
                print(f"SKIPPED    {description}  (control_logic.py has changed here)")
                continue
            (folder / "control_logic.py").write_text(original.replace(before, after))
            if tests_fail(folder):
                killed += 1
                print(f"killed     {description}")
            elif equivalent_because:
                survived_equivalent += 1
                print(f"survived   {description}\n"
                      f"           equivalent mutant: {equivalent_because}")
            else:
                survived_real += 1
                print(f"SURVIVED   {description}   <-- a gap in the tests")

    print(f"\n{killed} killed, {survived_equivalent} equivalent, "
          f"{survived_real} surviving mutants that need a new test.")


if __name__ == "__main__":
    main()
