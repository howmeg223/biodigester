"""
simulator.py - an MQTT stand-in for the digester hardware.

Run with:   python3 simulator.py

It plays the two hardware roles the controller talks to:
  * the temperature sensor   publishes readings on TOPIC_TEMPERATURE
  * the heater               obeys TOPIC_HEATER_CMD, reports on TOPIC_HEATER_STATE
with a DigesterModel between them, so the readings respond to the heater.

That link is why this is not a random-number publisher. With random data the
loop never closes: the controller could switch the heater all day and the
"temperature" would not care, so there would be nothing to regulate.

Start reading at main(): each loop advances the pretend tank and publishes
sensor readings. On the real digester, replace this program with one that
reads the real sensor and drives the real heater on these same topics. The
controller and the app do not change.

Faults can be injected over MQTT (the app has buttons for this):
  sensor_dropout    the sensor goes silent
  sensor_bad        the sensor publishes a nonsense value
  heater_failure    the heater ignores commands and stays off
  none              everything works
"""

import argparse
import random
import threading
import time

import config
from digester_model import DigesterModel, ambient_temperature
from mqtt_common import connect_and_start, connected_ok, make_client, read_json, send

FAULTS = ("none", "sensor_dropout", "sensor_bad", "heater_failure")
TICK_S = 0.2        # real seconds between physics updates


class SimulatedHardware:
    """The pretend sensor and heater. Shared between the MQTT thread and the main loop."""

    def __init__(self, start_c):
        # MQTT receives commands in another thread. This lock protects the tank
        # and heater values while the main loop is updating them.
        self.lock = threading.Lock()
        self.model = DigesterModel(temp_c=start_c,
                                   slurry_kg=config.SIM_SLURRY_KG,
                                   heater_w=config.SIM_HEATER_W,
                                   ua_w_per_k=config.SIM_UA_W_PER_K,
                                   heater_lag_s=config.SIM_HEATER_LAG_S)
        self.heater_on = False
        self.last_command_time = None
        self.fault = "none"

    def command(self, on):
        """A command arrived from the controller."""
        with self.lock:
            self.last_command_time = time.monotonic()
            if self.fault == "heater_failure":
                self.heater_on = False          # a broken heater stays off
            else:
                self.heater_on = on

    def set_fault(self, fault):
        """Remember the requested test fault; a broken heater stays off."""
        with self.lock:
            self.fault = fault
            if fault == "heater_failure":
                self.heater_on = False

    def watchdog(self):
        """Heater-side safety: no command for too long means switch off.

        Returns True if it had to act. This covers a crashed controller or a
        dead broker, which the controller itself can do nothing about.
        """
        with self.lock:
            if self.last_command_time is None:
                return False
            silent_for = time.monotonic() - self.last_command_time
            if self.heater_on and silent_for > config.HEATER_COMMAND_TIMEOUT_S:
                self.heater_on = False
                return True
        return False


def main():
    # 1. Read the optional --speed and --start terminal arguments.
    parser = argparse.ArgumentParser(description="Simulated digester on MQTT")
    parser.add_argument("--speed", type=float, default=config.SIM_SPEED,
                        help="simulated seconds per real second")
    parser.add_argument("--start", type=float, default=config.SIM_START_C,
                        help="starting temperature in °C")
    args = parser.parse_args()

    # 2. Set up the pretend hardware and its MQTT message handlers.
    hardware = SimulatedHardware(args.start)
    client = make_client("biodigester-simulator")

    def on_connect(client, userdata, flags, reason_code, *extra):
        """Subscribe again whenever MQTT connects or reconnects."""
        if connected_ok(reason_code):
            client.subscribe(config.TOPIC_HEATER_CMD, qos=1)
            client.subscribe(config.TOPIC_SIM_FAULT, qos=1)
            print("[simulator] Connected. Publishing readings.")

    def on_message(client, userdata, msg):
        """Handle a heater command or a simulator fault request."""
        data = read_json(msg)
        if data is None:
            return
        if msg.topic == config.TOPIC_HEATER_CMD:
            action = data.get("action")
            if action in ("ON", "OFF"):
                hardware.command(action == "ON")
        elif msg.topic == config.TOPIC_SIM_FAULT:
            fault = data.get("fault")
            if fault in FAULTS:
                hardware.set_fault(fault)
                print(f"[simulator] Fault set to: {fault}")

    client.on_connect = on_connect
    client.on_message = on_message
    connect_and_start(client, "simulator")

    # 3. Track simulated time separately from elapsed time on this computer.
    sim_time_s = 0.0
    last_tick = time.monotonic()
    next_reading = last_tick
    last_reported_heater = None
    readings_sent = 0

    try:
        # 4. Repeat: check safety, advance the tank, publish readings.
        while True:
            time.sleep(TICK_S)
            now = time.monotonic()
            elapsed_real_s = now - last_tick
            elapsed_simulated_s = elapsed_real_s * args.speed
            last_tick = now

            if hardware.watchdog():
                print("[simulator] No command from the controller: heater switched itself off.")

            with hardware.lock:
                ambient = ambient_temperature(sim_time_s, config.SIM_AMBIENT_MEAN_C,
                                              config.SIM_AMBIENT_SWING_C)
                true_temperature = hardware.model.step(elapsed_simulated_s, hardware.heater_on, ambient)
                heater_on = hardware.heater_on
                fault = hardware.fault
            sim_time_s += elapsed_simulated_s

            # The heater reports its state when it changes, and once per reading.
            if heater_on != last_reported_heater:
                send(client, config.TOPIC_HEATER_STATE,
                     {"state": "ON" if heater_on else "OFF"}, retain=True)
                last_reported_heater = heater_on

            if now >= next_reading:
                next_reading = now + config.SENSOR_PERIOD_S
                send(client, config.TOPIC_HEATER_STATE,
                     {"state": "ON" if heater_on else "OFF"}, retain=True)
                send(client, config.TOPIC_SIM_STATE,
                     {"fault": fault, "ambient": round(ambient, 1), "speed": args.speed},
                     retain=True)

                # The sensor: silent, nonsense, or the true temperature plus noise.
                if fault == "sensor_dropout":
                    pass
                elif fault == "sensor_bad":
                    send(client, config.TOPIC_TEMPERATURE,
                         {"temperature": config.SIM_BAD_READING_C})
                else:
                    reading = true_temperature + random.gauss(0, config.SIM_SENSOR_NOISE_C)
                    send(client, config.TOPIC_TEMPERATURE, {"temperature": round(reading, 2)})

                readings_sent += 1
                if readings_sent % 5 == 0:
                    print(f"[simulator] {true_temperature:6.2f} °C   ambient {ambient:5.1f} °C   "
                          f"heater {'ON ' if heater_on else 'OFF'}   fault: {fault}")
    except KeyboardInterrupt:
        print("\n[simulator] Stopped.")
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    main()
