"""
control_logic.py - the regulation logic for the biodigester heater.

Everything in this file is plain Python: no MQTT, no GUI, no hardware and no
clock. The current time is always passed in as a number of seconds. That is
what lets the same code be tested on any computer (test_control_logic.py), run
live (controller.py) and run in fast-forward (experiment.py).

Four layers, simplest first:
  1. decide_simple / decide_hysteresis   the on/off rule itself
  2. check_reading                       can this sensor reading be trusted?
  3. check_thresholds                    are thresholds sent by the app sane?
  4. Regulator                           combines 1-3 and adds the minimum
                                         on/off time and the alarms

Start with decide_hysteresis(): it is the basic heating rule. Then read
Regulator.update() to see how sensor checks, alarms and timers surround it.
"""

import math
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------------
# 1. The on/off rule
# ---------------------------------------------------------------------------
@dataclass
class Thresholds:
    """The temperature band to hold, in degrees C.

    @dataclass lets Python create the initialiser for these named values:
    Thresholds(low=35, high=37). midpoint is a calculated value, not a method
    you need to call: use target_range.midpoint, without parentheses.
    """
    low: float = 35.0    # colder than this -> heating must come on
    high: float = 37.0   # hotter than this -> heating must go off

    @property
    def midpoint(self):
        return (self.low + self.high) / 2


def decide_simple(temp_c, setpoint):
    """Baseline strategy: one threshold.

    Heat whenever the reading is below the setpoint. It has no memory, so a
    reading that wobbles around the setpoint flips the output every time.
    """
    return temp_c < setpoint


def decide_hysteresis(temp_c, heating, th):
    """Two thresholds with a hold zone between them.

    temp_c  : latest temperature reading (float, degrees C)
    heating : what the heating is doing right now (True = on)
    th      : the Thresholds to hold

    Returns True if the heating should be on after this reading.
    A reading exactly on a threshold counts as inside the band.
    """
    if temp_c < th.low:
        return True       # too cold: heat
    if temp_c > th.high:
        return False      # warm enough: stop
    return heating        # inside the band: keep doing what we were doing


# ---------------------------------------------------------------------------
# Settings, fault codes and alarm codes
# ---------------------------------------------------------------------------
@dataclass
class Settings:
    """Limits and timers for the Regulator. All times are in seconds.

    These defaults are useful for offline examples and tests. controller.py
    supplies the live settings from config.py when it creates its Regulator.
    """
    strategy: str = "hysteresis"      # "hysteresis" or "simple"
    stale_after_s: float = 10.0       # a reading older than this is not trusted
    plausible_min_c: float = 0.0      # readings outside this range are treated
    plausible_max_c: float = 70.0     #   as a broken sensor, not a temperature
    min_on_s: float = 5.0             # once on, stay on at least this long
    min_off_s: float = 5.0            # once off, stay off at least this long
    alarm_margin_c: float = 2.0       # alarm this far outside the band
    actuator_timeout_s: float = 5.0   # heater must match the command by then
    threshold_min_c: float = 20.0     # lowest threshold the app may set
    threshold_max_c: float = 60.0     # highest threshold the app may set
    min_band_c: float = 0.5           # low and high at least this far apart


# Faults: the reading cannot be trusted, so the heater is forced OFF.
NO_READING = "NO_READING"
SENSOR_STALE = "SENSOR_STALE"
SENSOR_BAD_VALUE = "SENSOR_BAD_VALUE"

# Alarms: the loop is still running, but someone should look at it.
TEMP_LOW = "TEMP_LOW"
TEMP_HIGH = "TEMP_HIGH"
HEATER_NOT_RESPONDING = "HEATER_NOT_RESPONDING"

# Plain-language text for each code, shown in the app and the logs.
MESSAGES = {
    NO_READING: "No temperature reading has arrived yet. Heating is off.",
    SENSOR_STALE: "The sensor has stopped reporting. Heating is off until readings return.",
    SENSOR_BAD_VALUE: "The sensor reading is not a believable temperature. Heating is off.",
    TEMP_LOW: "Temperature is well below the target range.",
    TEMP_HIGH: "Temperature is well above the target range.",
    HEATER_NOT_RESPONDING: "The heater is not doing what it was told.",
}


# ---------------------------------------------------------------------------
# 2. Can this reading be trusted?
# ---------------------------------------------------------------------------
def check_reading(temp_c, age_s, settings):
    """Return a fault code if the reading must not be used, otherwise None.

    temp_c : the latest reading, or None if nothing has ever arrived
    age_s  : seconds since that reading arrived, or None

    None means a value is missing. math.isfinite() rejects NaN ('not a number')
    and infinity. Returning None means all the checks passed.
    """
    if temp_c is None or age_s is None:
        return NO_READING
    if age_s > settings.stale_after_s:
        return SENSOR_STALE
    if not math.isfinite(temp_c):
        return SENSOR_BAD_VALUE
    if temp_c < settings.plausible_min_c or temp_c > settings.plausible_max_c:
        return SENSOR_BAD_VALUE
    return None


# ---------------------------------------------------------------------------
# 3. Are these thresholds sane?
# ---------------------------------------------------------------------------
def check_thresholds(low, high, settings):
    """Return None if (low, high) may be used, otherwise a reason to show the user."""
    try:
        low, high = float(low), float(high)
    except (TypeError, ValueError):
        return "Both temperatures must be numbers."
    if not (math.isfinite(low) and math.isfinite(high)):
        return "Both temperatures must be numbers."
    if low >= high:
        return "The lower temperature must be below the upper one."
    if high - low < settings.min_band_c:
        return f"The two temperatures must be at least {settings.min_band_c:g} °C apart."
    if low < settings.threshold_min_c or high > settings.threshold_max_c:
        return (f"Both temperatures must be between {settings.threshold_min_c:g} "
                f"and {settings.threshold_max_c:g} °C.")
    return None


# ---------------------------------------------------------------------------
# 4. The Regulator
# ---------------------------------------------------------------------------
@dataclass
class Decision:
    """What the Regulator decided on one update."""
    heating: bool                   # the command: should the heater be on?
    mode: str                       # "HEATING", "IDLE" or "FAULT"
    fault: Optional[str]            # a fault code, or None
    # Each Decision needs its own alarm list; default_factory creates a fresh one.
    alarms: List[str] = field(default_factory=list)
    reason: str = ""                # one plain sentence explaining the decision


class Regulator:
    """Decides, once per update, whether the heater should be on.

    Order of priority on every update:
      1. A reading that cannot be trusted forces the heater OFF immediately.
      2. A temperature far above the band forces the heater OFF immediately.
      3. Otherwise the on/off rule decides, but a change is only carried out
         once the minimum on/off time has passed.
    Safety (1 and 2) always beats the timer (3).
    """

    def __init__(self, thresholds=None, settings=None):
        if thresholds is None:
            thresholds = Thresholds()
        if settings is None:
            settings = Settings()
        self.th = thresholds           # th = thresholds; used by both monitors
        self.settings = settings
        self.heating = False            # current command
        self._last_switch = None        # time of the last on/off change
        self._mismatch_since = None     # when heater and command first disagreed

    # -- thresholds --------------------------------------------------------
    def set_thresholds(self, low, high):
        """Apply new thresholds if they are sane.

        Returns None on success, or the reason they were rejected. Rejected
        thresholds leave the current ones untouched.
        """
        problem = check_thresholds(low, high, self.settings)
        if problem is None:
            self.th = Thresholds(float(low), float(high))
        return problem

    # -- the decision ------------------------------------------------------
    def update(self, now, temp_c, reading_age_s, heater_reported_on=None):
        """Make one decision.

        now                : current time in seconds (any steadily rising clock)
        temp_c             : latest reading, or None if none has arrived
        reading_age_s      : seconds since that reading arrived, or None
        heater_reported_on : what the heater says it is doing, or None if it
                             gives no feedback
        """
        settings = self.settings

        # 1. Fail-safe. No trustworthy reading means no heating.
        fault = check_reading(temp_c, reading_age_s, settings)
        if fault:
            self._switch(False, now)
            alarms = self._heater_alarm(now, heater_reported_on)
            return Decision(False, "FAULT", fault, alarms, MESSAGES[fault])

        # 2. Alarms for a temperature well outside the band.
        alarms = []
        if temp_c < self.th.low - settings.alarm_margin_c:
            alarms.append(TEMP_LOW)
        if temp_c > self.th.high + settings.alarm_margin_c:
            alarms.append(TEMP_HIGH)

        # 3. Work out whether the temperature rule requests heating.
        if settings.strategy == "simple":
            requested_heating = decide_simple(temp_c, self.th.midpoint)
        else:
            requested_heating = decide_hysteresis(temp_c, self.heating, self.th)

        # 4. Apply that request if the timer allows it. Overheating bypasses it.
        if requested_heating == self.heating:
            reason = self._steady_reason(temp_c)
        elif not requested_heating and TEMP_HIGH in alarms:
            self._switch(False, now)
            reason = "Far above the target range: heating forced off."
        elif self._may_switch(now):
            self._switch(requested_heating, now)
            if requested_heating:
                reason = "Below the target range: heating switched on."
            else:
                reason = "Above the target range: heating switched off."
        elif self.heating:
            reason = "Warm enough, waiting out the minimum on time before switching off."
        else:
            reason = "Too cold, waiting out the minimum off time before heating again."

        alarms += self._heater_alarm(now, heater_reported_on)
        if self.heating:
            mode = "HEATING"
        else:
            mode = "IDLE"
        return Decision(self.heating, mode, None, alarms, reason)

    # -- helpers -----------------------------------------------------------
    def _switch(self, on, now):
        """Change the command and remember when it changed."""
        if on != self.heating:
            self.heating = on
            self._last_switch = now

    def _may_switch(self, now):
        """Has the heater been in its current state for long enough?"""
        if self._last_switch is None:
            return True
        if self.heating:
            minimum_duration = self.settings.min_on_s
        else:
            minimum_duration = self.settings.min_off_s
        time_in_current_state = now - self._last_switch
        return time_in_current_state >= minimum_duration

    def _steady_reason(self, temp_c):
        if temp_c < self.th.low:
            return "Below the target range: heating."
        if temp_c > self.th.high:
            return "Above the target range: heating off."
        if self.heating:
            return "Inside the target range: heating until the top of the range."
        return "Inside the target range: heating off until the bottom of the range."

    def _heater_alarm(self, now, reported_on):
        """Alarm if the heater has disagreed with the command for too long."""
        if reported_on is None or reported_on == self.heating:
            self._mismatch_since = None
            return []
        if self._mismatch_since is None:
            self._mismatch_since = now
        if now - self._mismatch_since >= self.settings.actuator_timeout_s:
            return [HEATER_NOT_RESPONDING]
        return []
